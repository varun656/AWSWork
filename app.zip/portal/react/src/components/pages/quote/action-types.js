export const QUOTE_LIST   = 'QUOTE_LIST'
export const QUOTE_ADD    = 'QUOTE_ADD'
export const QUOTE_UPDATE = 'QUOTE_UPDATE'
export const QUOTE_REMOVE = 'QUOTE_REMOVE'

export default {
    QUOTE_LIST,
    QUOTE_ADD,
    QUOTE_UPDATE,
    QUOTE_REMOVE,
}