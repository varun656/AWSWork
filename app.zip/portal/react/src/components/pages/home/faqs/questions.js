const questions = [
    {
        id: 1,
        title: 'What does my expat policy cover?',
        info:
            'Our policy is a full medical plan. This means it covers all of your medical needs from preventative care, to any injuries or illnesses that occur at your new home.',
    },
    {
        id: 2,
        title: 'Where am I covered with my policy?',
        info:
            'Our policy is a full medical plan. This means it covers all of your medical needs from preventative care, to any injuries or illnesses that occur at your new home.',
    },
    {
        id: 3,
        title: 'What is an expat?',
        info:
            'Our policy is a full medical plan. This means it covers all of your medical needs from preventative care, to any injuries or illnesses that occur at your new home.',
    },
]
export default questions