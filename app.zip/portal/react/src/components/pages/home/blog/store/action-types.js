export const BLOG_LIST   = 'BLOG_LIST'
export const BLOG_ADD    = 'BLOG_ADD'
export const BLOG_UPDATE = 'BLOG_UPDATE'
export const BLOG_REMOVE = 'BLOG_REMOVE'

export default {
    BLOG_LIST,
    BLOG_ADD,
    BLOG_UPDATE,
    BLOG_REMOVE,
}