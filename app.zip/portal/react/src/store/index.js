import storeConfig from './config'

export default storeConfig()
