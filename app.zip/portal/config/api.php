<?php

return [
  // api version
    'api_version' => env('API_VERSION', 'v1'),
];
