export const API_CONSTANTS = {
    LEAD: 'api/lead/2',
};