// user action types
export const USER_UPDATE = 'USER_UPDATE'
export const USER_UNSET = 'USER_UNSET'

export default {
  USER_UPDATE,
  USER_UNSET,
}